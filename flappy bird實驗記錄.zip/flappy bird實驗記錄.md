﻿**flappy bird dqn實作結果**

**介紹:**

用DQN、Double DQN 和 Dueling dqn 來訓練模型玩flappybird 遊戲。

**參數(基本上五個實作的參數都相同):**

- image\_size=84
- batch\_size=32
- optimizer=adam
- lr=1e-6
- gamma=0.99
- initial\_epsilon=0.1
- final\_epsilon=1e-4
- num\_iterst=2000000
- replay\_memory\_size=50000
- target\_update=10000(無target模型沒有此參數)
- warn up stept=10000(無target模型沒有此參數)

**實作一(無target網路):**

**分析:**

Qvalue:

圖一的x軸是步數，Y軸是q-value，由圖1可知此模型的qvalue噪聲很大，模型並不是呈現穩定上升而是先上升到100萬步時達到峰值在下降，到180萬不時又上升，可知此模型計算出的q值非常不穩定。

![A graph showing the growth of the stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.001.png)




`                                     `圖一: Qvalue


Epsilon:

圖二x軸是步數，y軸是Epsilon值，由圖二可知初期高的探索後期，後期更高的利用

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.002.png)








`      `圖二: Epsilon

Loss:

圖3的x軸是步數，Y軸是loss，由圖3可知模型並不是呈現穩定下降，而是先下降到40萬步時達到低值在上升。

![A graph showing a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.003.png)






圖三:loss值





Reward:

` `圖4的x軸是步數，Y軸是reward，由圖4可知模型前期並不能取得夠好的獎勵，而是要到100萬步後獎勵才會開始上升。



![A graph showing the value of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.004.png)






`					`圖四:reward	

最終結果:

100萬步:模型只能勉強穿過第一個柱子偶爾運氣好可以穿過第二或第三個柱子。

200萬步:模型差不多無敵了

**實作二(有target dqn網路):**

**分析:**

Qvalue:

![A graph showing the growth of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.005.png)圖一的x軸是步數，Y軸是q-value，相比圖1模型的qvalue噪聲很大這次噪聲變小很多，q值呈現穩定上升前期上升較平緩，中期較陡，後期又趨於平緩，最大ｑ值為：9.4811，平滑值為9.0573。





`                                     `圖一: Qvalue


Epsilon:

圖二x軸是步數，y軸是Epsilon值，由圖二可知初期高的探索後期，後期更高的利用

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.006.png)








`      `圖二: Epsilon

Loss:

圖3的x軸是步數，Y軸是loss，由圖3可知模型並不是呈現穩定下降，而是先微微下降到20萬步時達到低值在上升到大約120萬步達到峰值在平緩下降。

![A graph showing a line of a stock market

Description automatically generated with medium confidence](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.007.png)






圖三:loss值



Reward:

` `圖4的x軸是步數，Y軸是reward，由圖4可知模型前期並不能取得夠好的獎勵，而是要到100萬步後獎勵才會開始上升。

![A graph showing the value of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.008.png)	







`					`圖四:reward	

最終結果:

100萬步:模型可以穿到30個柱子多才會失敗。

200萬步:模型差不多無敵了

**實作三(有target dqn網路加上預先收集1萬筆資料):**

**分析:**

Qvalue:

圖一的x軸是步數，Y軸是q-value，相比實驗二模型的qvalue整體曲線沒有差很多，最大ｑ值為：9.8797相比實驗2大，而平滑值:8.5993相比實驗二較小

![A graph showing the growth of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.009.png)




`                                                    `圖一: Qvalue


Epsilon:

圖二x軸是步數，y軸是Epsilon值，由圖二可知初期高的探索後期，後期更高的利用

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.010.png)








`      `圖二: Epsilon

Loss:

圖3的x軸是步數，Y軸是loss，相比實驗二，而是先急遽下降到20萬步時達到低值在上升到大約160萬步達到峰值在平緩下降。

![A graph showing the growth of the stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.011.png)






圖三:loss值



Reward:

` `圖4的x軸是步數，Y軸是reward，由圖4可知模型前期並不能取得夠好的獎勵，而是要到90萬步後獎勵才會開始上升，相比實驗二模型在可以更早取得較好的獎勵。

![A graph showing the value of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.012.png)	






`					`圖四:reward	

最終結果:

100萬步:模型可以穿到30個柱子多才會失敗，但穩定性不好有時只能到個位數。

200萬步:模型差不多無敵了

**實作四(double dqn網路加上預先收集1萬筆資料):**

**分析:**

Qvalue:

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.013.png)圖二的x軸是步數，Y軸是q-value，相比圖二模型的qvalue整體曲線沒有差很多，最大ｑ值為：9.4811相比實驗3小，而平滑值:8.096相比實驗三較小。







`  `圖一: Qvalue


Epsilon:

圖二x軸是步數，y軸是Epsilon值，由圖二可知初期高的探索後期，後期更高的利用

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.014.png)








`      `圖二: Epsilon

Loss:

圖3的x軸是步數，Y軸是loss，相比實驗二，而是先緩緩下降到40萬步時達到低值在上升到大約160萬步達到峰值在急遽下降。比起實驗三初期學習較慢，在 400k ~ 1.4M 步之間，損失值上升的幅度略低於 實驗三。平滑值為0.0526略大於實驗三。

![A graph showing the growth of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.015.png)






圖三:loss值




Reward:

` `圖4的x軸是步數，Y軸是reward，由圖4可知模型前期並不能取得夠好的獎勵，而是要到100萬步後獎勵才會開始上升，但之後卻又下降???

![A graph with lines and numbers

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.016.png)	







`					`圖四:reward	


最終結果:

100萬步:模型可以穿到30個柱子多才會失敗，但穩定性非常不好有時甚至連第一個柱子都穿不過去。

200萬步:模型差不多無敵了








**實作五(double dueling dqn網路加上預先收集1萬筆資料):**

**分析:**

Qvalue:

圖二的x軸是步數，Y軸是q-value，相比實驗4模型的qvalue在中期時增長速度較快，最大ｑ值為：9.3523相比實驗4小，而平滑值:8.5953相比實驗4較大。

![A graph showing the growth of a stock market

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.017.png)






`  `圖一: Qvalue


Epsilon:

圖二x軸是步數，y軸是Epsilon值，由圖二可知初期高的探索後期，後期更高的利用

![A graph with a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.018.png)








`      `圖二: Epsilon



Loss:

![A graph showing a line

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.019.png)圖3的x軸是步數，Y軸是loss，相比實驗4，初期（0 ~ 200k 步）：損失值快速下降，顯示出較快的學習能力。中期（200k ~ 1M 步）：損失值保持在低水平，穩定性較好。後期（1M ~ 2M 步）：損失值略微上升後快速下降。平滑值為0.0261小於實驗四。







圖三:loss值

Reward:

` `圖4的x軸是步數，Y軸是reward，相比於實驗5模型在前期就可以取得較好的獎勵(約60-80萬步)，雖然之後有些微下降，但在140萬步時又急遽上升。

![A graph showing the value of a step

Description automatically generated](Aspose.Words.33eec03b-3b51-4ac9-97b4-89d06175deee.020.png)	







`					`圖四:reward	


最終結果:

100萬步:模型最多可以無敵，但穩定性非常不好有時只能穿過20-30。

200萬步:模型無敵了

**改進**

1. 應該要在tensorboard上下載csv檔案，這樣可以更容易生成比較圖表在做數據分析時也較容易。
1. 儲存模型間隔可以在更小，每50萬步保存模型，這樣更知道模型收斂速度。
1. 預先收集資料1萬筆有點太多，這樣讓模型最終有一點不穩定
1. 想開發並行環境訓練開多個視窗玩flappy bird看可不可以加快模型收斂
1. 程式碼可移植性不高，每次換新電腦都要修改路徑。

